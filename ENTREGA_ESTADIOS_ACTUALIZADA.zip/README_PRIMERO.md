# Entrega por estadios

Documento: reports/v9_estadios/DOCUMENTO_TECNICO_ESTADIOS.pdf.

## Abrir el simulador

Con Python 3.12 instalado, abre ABRIR_DASHBOARD.bat. La primera apertura crea un entorno local y descarga las herramientas; requiere internet y puede tardar varios minutos. Despues abre el mismo archivo cada vez que quieras usar el tablero. Manten su ventana abierta durante el uso. No necesita el dataset original para simular con los modelos incluidos.

La vista inicial explica como leer los resultados. En Comparar un lanzamiento hay perfiles para Harp Helu, simulacion, mapa y evidencia.

## Evidencia y limites

Tres evaluaciones completas de 13 tareas: temporada, pitchers reservados y Harp Helu excluido del entrenamiento. Consultar metricas, recomendaciones y ESTADO_ENTREGA.md. 2026 es un benchmark reutilizado; no hay efecto causal ni mejora incremental de carreras por estadio confirmados. Incluye probabilidad de out al cerrar el turno, indice integral y comparacion historica normalizada por temporada y estadio; consulta sus definiciones en la pagina 9 del PDF.

El paquete contiene modelos y resultados derivados con identificadores anonimos. Uso exclusivo de la competencia. No contiene mediciones ni outcomes originales. Completar nombres y correos del equipo antes de enviar por el canal autorizado.
