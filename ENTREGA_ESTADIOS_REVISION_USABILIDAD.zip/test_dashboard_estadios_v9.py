import unittest
from pathlib import Path

import pandas as pd
from streamlit.testing.v1 import AppTest
from proyecto_io import bundle_ready

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / 'stuff_plus_output_v9_estadios'


@unittest.skipUnless(bundle_ready(OUTPUT), 'Requiere modelos por estadios completos')
class StadiumDashboardTests(unittest.TestCase):
    def app(self):
        app = AppTest.from_file(str(ROOT / 'dashboard_stuff_plus.py')).run(timeout=60)
        self.assertEqual(list(app.exception), [])
        return app

    def select(self, app, key):
        return next(w for w in app.selectbox if w.key == key)

    def submit(self, app):
        next(b for b in app.button if b.label == 'Comparar en Harp').click().run(timeout=60)
        self.assertEqual(list(app.exception), [])

    def navigate(self, app, page):
        next(r for r in app.radio if r.key == 'coach_workspace').set_value(page).run(timeout=60)
        self.assertEqual(list(app.exception), [])

    def test_starts_with_two_stadiums_and_requires_confirmation(self):
        app = self.app()
        self.assertEqual(self.select(app, 'comparison_reference').value, 'veracruz_avila')
        self.assertFalse(app.metric)
        self.assertFalse(any(s.key == 'coach_profile_type' for s in app.selectbox))
        self.submit(app)
        physical = [m.value for m in app.metric if m.label == 'Stuff+ · física']
        self.assertEqual(len(physical), 2)
        self.assertEqual(len(set(physical)), 1)
        self.assertTrue(any('Pitching+ no cambia' in item.value for item in app.info))
        self.assertTrue(any('jonrón' in item.value for item in app.warning))
        table = app.dataframe[0].value
        self.assertEqual(len(table), 3)
        self.assertTrue(((table.Harp - table.Referencia - table['Diferencia (puntos porcentuales)']).abs() <= .00101).all())

    def test_measurements_survive_navigation_and_stadium_change_invalidates_result(self):
        app = self.app()
        next(w for w in app.number_input if w.label == 'Velocidad (mph)').set_value(94.0)
        self.submit(app)
        before = [m.value for m in app.metric if m.label == 'Stuff+ · física']
        self.navigate(app, 'Evidencia y entrega')
        self.assertEqual(len([m for m in app.metric if m.label == 'Reducción del error']), 3)
        self.navigate(app, 'Comparar en Harp')
        self.assertEqual(next(w.value for w in app.number_input if w.label == 'Velocidad (mph)'), 94.0)
        self.assertEqual([m.value for m in app.metric if m.label == 'Stuff+ · física'], before)
        self.select(app, 'comparison_reference').set_value('campeche_barrera').run(timeout=60)
        self.assertFalse(app.metric)
        self.submit(app)
        self.assertEqual([m.value for m in app.metric if m.label == 'Stuff+ · física'], before)

    def test_profile_transfer_and_missing_support(self):
        app = self.app()
        self.navigate(app, 'Perfiles para scouting')
        self.select(app, 'coach_profile_type').set_value('Knuckleball').run(timeout=60)
        self.assertTrue(any('Muestra insuficiente' in w.value for w in app.warning))
        self.select(app, 'coach_profile_type').set_value('Slider').run(timeout=60)
        selected_hand = self.select(app, 'coach_profile_hand').value
        next(b for b in app.button if b.label == 'Comparar este perfil en Harp').click().run(timeout=60)
        self.assertEqual(list(app.exception), [])
        self.assertEqual(self.select(app, 'sim_pitch_type').value, 'Slider')
        self.assertEqual(self.select(app, 'sim_hand').value, selected_hand)
        self.assertFalse(app.metric)

    def test_pitcher_selection_filters_scores_map_and_arsenal(self):
        app = self.app()
        self.navigate(app, 'Revisar un pitcher')
        chooser = self.select(app, 'movement_pitcher')
        chosen = chooser.options[-1]
        chooser.set_value(chosen).run(timeout=60)
        self.assertEqual(list(app.exception), [])
        tables = [df.value for df in app.dataframe]
        ficha = next(df for df in tables if 'Lanzador anónimo' in df.columns)
        self.assertEqual(set(ficha['Lanzador anónimo']), {chosen})
        self.assertEqual(set(tables[-1]['Lanzador anónimo']), {chosen})
        self.navigate(app, 'Comparar en Harp')
        self.navigate(app, 'Revisar un pitcher')
        self.assertEqual(self.select(app, 'movement_pitcher').value, chosen)

    def test_extra_stadium_does_not_duplicate_reference_and_shap_still_works(self):
        app = self.app()
        app.multiselect[0].set_value(['campeche_barrera']).run(timeout=60)
        self.submit(app)
        self.assertEqual(len([m for m in app.metric if m.label == 'Stuff+ · física']), 3)
        next(b for b in app.button if b.label == 'Explicar este pitch').click().run(timeout=60)
        self.assertEqual(list(app.exception), [])
        self.assertTrue(any('Atribuciones SHAP' in c.value for c in app.caption))
        self.select(app, 'comparison_reference').set_value('campeche_barrera').run(timeout=60)
        self.assertEqual(app.multiselect[0].value, [])
        self.assertFalse(app.metric)

    def test_displayed_scores_match_frozen_inference(self):
        from dashboard_stuff_plus_v9 import stadium_scenarios
        from entrenar_stuff_plus_v9 import load_bundle, infer
        bundle = load_bundle(OUTPUT)
        profile = next(p for p in bundle[0]['input_profiles'] if p['type'] == 'Four-Seam' and p['hand'] == 'Right')
        row = dict(profile['median'], AutoPitchType='Four-Seam', PitcherThrows='Right',
                   pitcher_anon_id='Sin historial', BatterSide='Right', PlateLocHeight=2.5,
                   PlateLocSide=0.0, Balls=0, Strikes=0)
        scenarios = stadium_scenarios(row, pd.read_csv(OUTPUT / 'estadios.csv'), ['mexico_ahh', 'veracruz_avila'])
        expected = infer(scenarios, bundle)
        app = self.app()
        self.submit(app)
        self.assertEqual([m.value for m in app.metric if m.label == 'Stuff+ · física'],
                         [f'{v:.1f}' for v in expected.stuff_plus])
        self.assertEqual([m.value for m in app.metric if m.label == 'Pitching+ · combinado'],
                         [f'{v:.1f}' for v in expected.pitching_plus])


if __name__ == '__main__':
    unittest.main()
