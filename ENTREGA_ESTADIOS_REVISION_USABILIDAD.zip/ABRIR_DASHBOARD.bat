@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto dependencies
echo Preparando el tablero. Necesitas Python 3.12 instalado.
py -3.12 -m venv .venv
if exist ".venv\Scripts\python.exe" goto dependencies
echo No se encontro Python 3.12. Instala Python y vuelve a abrir este archivo.
pause
exit /b 1
:dependencies
if exist ".venv\dashboard-listo" goto run
echo La primera apertura descarga las herramientas. Necesitas internet.
".venv\Scripts\python.exe" -m pip install -r requirements-portable.txt
if errorlevel 1 goto failed
echo listo > ".venv\dashboard-listo"
:run
echo Abriendo el tablero. Manten esta ventana abierta mientras lo usas.
".venv\Scripts\python.exe" -m streamlit run dashboard_stuff_plus.py --server.address 127.0.0.1
if errorlevel 1 goto failed
exit /b 0
:failed
echo No fue posible abrir el tablero. Conserva este mensaje para el equipo de soporte.
pause
exit /b 1
