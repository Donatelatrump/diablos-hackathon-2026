# Entrega revisada: comparación en Harp

Con Python 3.12 instalado, abrir ABRIR_DASHBOARD.bat. La primera apertura requiere internet para instalar dependencias. Mantener su ventana abierta durante el uso. No se necesita el dataset original para inferencia.

El inicio abre Comparar en Harp. Elegir tipo, mano y estadio de referencia; revisar mediciones y contexto; pulsar Comparar en Harp. Las entradas iniciales son un ejemplo con medianas, no un lanzamiento observado. Después de editar, volver a pulsar el botón.

Revisar un pitcher conserva una selección para ficha, mapa y arsenal. Perfiles para scouting compara grupos; permite trasladar tipo y mano al simulador. Evidencia y entrega reúne validaciones y pendientes.

Consultar reports/v9_estadios/MEJORAS_2026-10-28.md para el recorrido actualizado. Esta nota sustituye las instrucciones de navegación del PDF técnico de nueve páginas. Sus definiciones y resultados de modelos se conservan.

No hay mejora incremental de carreras por estadio confirmada ni un arsenal óptimo demostrado para Harp. Las probabilidades y el índice complementario pueden cambiar; el contraste mantiene fija la física y no prueba efectos causales. 2026 es reutilizado.

Uso exclusivo de la competencia. Completar nombres y correos del equipo y confirmar envío por el canal autorizado. Este script no envía ni publica el paquete.
