"""Coach-oriented simulation using the exact frozen v9 inference pipeline."""
import json
import hashlib
from pathlib import Path
import altair as alt
import pandas as pd
import streamlit as st
import entrenar_stuff_plus_v9 as v9
from dashboard_style import apply_dashboard_style
from dashboard_perfiles_estadios import render_profiles, render_validation_summary, PITCH_NAMES, HANDS, TASK_NAMES


@st.cache_resource
def get_bundle(path, modified):
    return v9.load_bundle(path)


def stadium_scenarios(row, catalog, selected):
    """Each stadium carries its development altitude category, with fixed pitch physics."""
    indexed = catalog.set_index("stadium_id")
    return pd.DataFrame([
        {**row, "PitchUID": f"scenario-{i}", "stadium_id": identifier,
         "stadium": indexed.loc[identifier, "estadio"],
         "altitude_category": indexed.loc[identifier, "altitude_category"]}
        for i, identifier in enumerate(selected)
    ])


def render(output):
    output = Path(output)
    bundle = get_bundle(str(output), (output / "bundle.json").stat().st_mtime_ns)
    # Keep existing widget values when moving between the task screens.
    persistent = {"sim_pitch_type", "sim_hand", "coach_profile_type", "coach_profile_hand",
                  "movement_pitcher", "movement_color", "filter_pitchers", "comparison_reference",
                  "comparison_extra_stadiums"}
    for profile in bundle[0]["input_profiles"]:
        prefix = f"{profile['type']}-{profile['hand']}-"
        persistent.update(key for key in st.session_state if key.startswith(prefix))
    active = st.session_state.get("coach_workspace", "Comparar en Harp")
    current_prefix = f"{st.session_state.get('sim_pitch_type', 'Four-Seam')}-{st.session_state.get('sim_hand', 'Right')}-"
    for key in persistent:
        visible = ((active == "Comparar en Harp" and (key.startswith("sim_") or key.startswith("comparison_") or key.startswith(current_prefix)))
                   or (active == "Revisar un pitcher" and key in {"movement_pitcher", "movement_color", "filter_pitchers"})
                   or (active == "Perfiles para scouting" and key.startswith("coach_profile_")))
        if key in st.session_state and not visible:
            st.session_state[key] = st.session_state[key]

    workspace = st.radio("¿Qué quieres hacer?",
        ["Comparar en Harp", "Revisar un pitcher", "Perfiles para scouting", "Evidencia y entrega"],
        horizontal=True, key="coach_workspace")
    if workspace == "Comparar en Harp":
        st.title("Un lanzamiento, dos estadios")
        st.caption("1. Elige el perfil · 2. Revisa las mediciones y el contexto · 3. Compara con Harp Helú")
        render_simulation(output, bundle)
    elif workspace == "Revisar un pitcher":
        st.title("Revisar un pitcher")
        render_rankings(output)
    elif workspace == "Perfiles para scouting":
        st.title("Perfiles de referencia para scouting")
        render_profiles(output.parent / 'reports/v9_estadios', bundle[0]["input_profiles"])
    else:
        st.title("Evidencia y entrega")
        render_evidence(output, bundle)


def render_simulation(output, bundle):
    meta = bundle[0]
    profiles = meta["input_profiles"]
    with st.expander("Cómo usar la comparación"):
        st.write("Elige tipo y mano. Revisa las mediciones del ejemplo y el contexto activo. Pulsa Comparar en Harp; después de editar, vuelve a pulsarlo para actualizar.")
        st.caption("La comparación conserva la física medida y cambia el contexto de estadio. No calcula cómo cambiaría el movimiento al trasladar al pitcher.")

    # Profile selection
    with st.container(key="tour-profile"):
        st.subheader("1. Perfil del lanzamiento")
        left, right = st.columns(2)
        pitch_type = left.selectbox(
            "Tipo de lanzamiento",
            sorted({p["type"] for p in profiles}, key=lambda value: (value != "Four-Seam", value)),
            key="sim_pitch_type",
            format_func=lambda value: PITCH_NAMES.get(value, value)
        )
        hand = right.selectbox(
            "Mano del pitcher",
            sorted({p["hand"] for p in profiles if p["type"] == pitch_type}, key=lambda value: (value != "Right", value)),
            key="sim_hand",
            format_func=lambda value: HANDS.get(value, value)
        )

    profile = next(p for p in profiles if p["type"] == pitch_type and p["hand"] == hand)
    row = {
        **profile["median"],
        "AutoPitchType": pitch_type,
        "PitcherThrows": hand,
        "pitcher_anon_id": "unknown",
        "PitchUID": "simulation",
        "BatterSide": "Right",
        "PlateLocHeight": 2.5,
        "PlateLocSide": 0.0,
        "Balls": 0,
        "Strikes": 0,
        "altitude_category": "No Altitude",
    }

    st.info("Ejemplo con medianas de entrenamiento. No es un lanzamiento observado ni una recomendación para Harp. Sustituye las mediciones por las del mismo lanzamiento si tienes datos reales.")
    stadium_context = "stadium_id" in meta["tasks"]["environment_run_value"]["features"]
    selected_stadiums = []
    if stadium_context:
        catalog = pd.read_csv(output / "estadios.csv")
        indexed = catalog.set_index("stadium_id")
        if "mexico_ahh" not in indexed.index:
            st.error("El catálogo no incluye Harp Helú. Revisa los archivos del modelo.")
            return
        identifiers = [identifier for identifier in catalog.stadium_id if identifier != "mexico_ahh"]
        if not identifiers:
            st.info("Hace falta otro estadio en el catálogo para comparar.")
            return
        st.markdown("**Harp Helú se compara siempre con el estadio que elijas.**")
        reference = st.selectbox("Estadio de referencia", identifiers,
            index=identifiers.index("veracruz_avila") if "veracruz_avila" in identifiers else 0,
            format_func=lambda identifier: indexed.loc[identifier, "estadio"], key="comparison_reference")
        with st.expander("Añadir un tercer estadio"):
            extras = [identifier for identifier in identifiers if identifier != reference]
            if any(identifier not in extras for identifier in st.session_state.get("comparison_extra_stadiums", [])):
                st.session_state["comparison_extra_stadiums"] = []
            extra = st.multiselect("Estadios adicionales", extras, max_selections=1,
                format_func=lambda identifier: indexed.loc[identifier, "estadio"], key="comparison_extra_stadiums")
        selected_stadiums = ["mexico_ahh", reference, *extra]
        category = indexed.loc[reference, "altitude_category"]
        st.caption("Referencia a nivel del mar / categoría sin altitud." if category == "No Altitude"
                   else "Este estadio no pertenece a la categoría sin altitud; el contraste usa su contexto registrado.")
    else:
        st.info("Esta versión compara categorías de altitud; no identifica estadios concretos.")

    with st.form("harp_comparison", enter_to_submit=False):
        # Physical measurements
        with st.container(key="tour-measurements"):
            st.subheader("2. Mediciones físicas")
            controls = [
                ("RelSpeed", "Velocidad (mph)"),
                ("InducedVertBreak", "IVB (pulgadas)"),
                ("HorzBreak", "HB (pulgadas)"),
                ("SpinRate", "Spin (rpm)"),
            ]
            field_cues = {
                "RelSpeed": ("↗", "Rapidez al salir", "Velocidad de la pelota al salir de la mano del pitcher, en millas por hora."),
                "InducedVertBreak": ("↕", "Movimiento vertical", "Cuánto se desvía verticalmente el lanzamiento por su movimiento aerodinámico, en pulgadas."),
                "HorzBreak": ("↔", "Movimiento lateral", "Cuánto se desvía a los lados, en pulgadas. La orientación depende de la mano del pitcher."),
                "SpinRate": ("⟳", "Giro de la pelota", "Velocidad de rotación de la pelota, en revoluciones por minuto (rpm)."),
            }

            cols = st.columns(2)
            for i, (key, label) in enumerate(controls):
                col = cols[i % len(cols)]
                value = row[key]
                icon, cue, explanation = field_cues[key]
                col.caption(cue)
                row[key] = col.number_input(
                    label,
                    value=float(value) if value is not None else None,
                    help=explanation,
                    key=f"{pitch_type}-{hand}-{key}",
                )

        # Advanced context
        with st.container(key="tour-advanced"):
            st.subheader("3. Ubicación, conteo e historial")
            with st.expander("Revisar contexto y mediciones adicionales", expanded=False):
                st.caption("Punto de salida del pitcher · posición de la pelota al llegar al plato · contexto del bateador y el repertorio previo.")

                advanced = [
                    ("EffectiveVelo", "Velocidad efectiva (mph)"),
                    ("SpinAxis", "Eje de spin (grados)"),
                    ("RelHeight", "Altura de release (pies)"),
                    ("RelSide", "Lado de release (pies)"),
                    ("Extension", "Extensión (pies)"),
                    ("VertBreak", "Break vertical total (pulgadas)"),
                    ("PlateLocHeight", "Altura en plato (pies)"),
                    ("PlateLocSide", "Lado en plato (pies)"),
                ]
                cols = st.columns(3)
                for i, (key, label) in enumerate(advanced):
                    value = row[key]
                    row[key] = cols[i % 3].number_input(
                        label,
                        value=float(value) if value is not None else None,
                        key=f"{pitch_type}-{hand}-{key}",
                    )

                row["Balls"] = cols[0].number_input("Bolas", 0, 3, 0, key=f"{pitch_type}-{hand}-Balls")
                row["Strikes"] = cols[1].number_input("Strikes", 0, 2, 0, key=f"{pitch_type}-{hand}-Strikes")
                row["BatterSide"] = cols[2].selectbox("Lado del bateador", ["Right", "Left"], format_func=lambda value: HANDS.get(value, value), key=f"{pitch_type}-{hand}-BatterSide")

                known = sorted({r["pitcher_anon_id"] for r in meta["profile"]["fastballs"]})
                row["pitcher_anon_id"] = st.selectbox(
                    "Arsenal histórico",
                    ["Sin historial", *known],
                    key=f"{pitch_type}-{hand}-arsenal",
                    help="Solo incorpora su historial de repertorio. No carga mediciones ni representa un lanzamiento observado de ese pitcher.",
                )

        submitted = st.form_submit_button("Comparar en Harp", type="primary", use_container_width=True)
    st.caption(f"Contexto activo: conteo {row['Balls']}-{row['Strikes']} · bateador {HANDS.get(row['BatterSide'], row['BatterSide']).lower()} · ubicación {row['PlateLocSide']} lateral / {row['PlateLocHeight']} de altura (pies) · historial: {row['pitcher_anon_id']}.")
    signature = json.dumps({"row": row, "stadiums": selected_stadiums, "bundle": str(output),
                            "modified": (output / "bundle.json").stat().st_mtime_ns}, sort_keys=True, default=str)
    if submitted:
        st.session_state["_confirmed_comparison"] = signature
    if st.session_state.get("_confirmed_comparison") != signature:
        st.info("Revisa los datos y pulsa Comparar en Harp para obtener resultados.")
        return
    st.caption("Resultados de la última comparación enviada. Después de editar el formulario, pulsa Comparar en Harp para actualizarlos.")

    # Validation warnings
    missing = [key for key in profile["median"] if row.get(key) is None]
    if missing:
        st.warning("Completa las mediciones para simular: " + ", ".join(missing))
    else:
        outside = [
            key for key in profile["median"]
            if profile["p01"][key] is not None and not profile["p01"][key] <= row[key] <= profile["p99"][key]
        ]
        if outside:
            st.warning("Fuera del rango central 98% de entrenamiento para este tipo y mano: " + ", ".join(outside))

        st.caption(
            f"Perfil basado en {profile['n']:,} pitches de entrenamiento. "
            "Estar dentro de rangos individuales no garantiza que la combinación esté bien representada."
        )

        # Run simulation
        scenarios = pd.DataFrame([
            {**row, "PitchUID": f"scenario-{i}", "altitude_category": category}
            for i, category in enumerate(["No Altitude", "Medium Altitude", "Extreme Altitude"])
        ])
        if stadium_context:
            scenarios = stadium_scenarios(row, catalog, selected_stadiums)
        predicted = v9.infer(scenarios, bundle)
        complement = Path(__file__).resolve().parent / 'reports/v9_estadios/complemento/season'
        has_complement = output.name == 'stuff_plus_output_v9_estadios' and (complement / 'indice_integral.json').exists()
        if has_complement:
            from indice_integral import enrich_scenarios
            predicted = enrich_scenarios(scenarios, predicted, bundle, complement)
        labels = ["Sin altitud", "Altitud media", "Altitud extrema"]
        if stadium_context:
            labels = scenarios.stadium.tolist()

        # Same reference and same measurements in every column.
        with st.container(key="tour-results"):
            st.subheader("Qué cambia en Harp")
            delta = predicted.iloc[0].pitching_plus - predicted.iloc[1].pitching_plus
            if abs(delta) < 1e-8:
                st.info("Pitching+ no cambia: el modelo no confirmó una mejora adicional de carreras al incorporar el estadio. Esto no demuestra que la altitud no tenga efecto.")
            else:
                st.write(f"Pitching+ en Harp frente a la referencia: **{delta:+.2f} puntos**. Diferencia predictiva con las mismas mediciones.")
            result_cols = st.columns(len(labels))
            for col, label, (_, result) in zip(result_cols, labels, predicted.iterrows()):
                with col:
                    with st.container(border=True):
                        st.markdown(f"#### {label}")
                        st.metric("Pitching+ · combinado", f"{result.pitching_plus:.1f}")
                        st.metric("Stuff+ · física", f"{result.stuff_plus:.1f}")
            st.caption("Referencia histórica fija y compartida: 100 es el promedio de calibración; 110 representa una desviación estándar favorable. Stuff+ conserva las mismas propiedades físicas entre escenarios.")
            changes = []
            for key, title, denominator, higher_better in [
                ("p_whiff", "Swing fallido", "100 lanzamientos", True),
                ("p_hard_contact", "Contacto duro", "100 contactos con velocidad medida", False),
                ("p_home_run_per_pitch", "Jonrón", "100 lanzamientos", False)]:
                if key in predicted:
                    harp, ref = 100 * predicted.iloc[0][key], 100 * predicted.iloc[1][key]
                    change = harp - ref
                    changes.append({"Resultado": title, "Por cada": denominator,
                        "Harp": round(harp, 3), "Referencia": round(ref, 3),
                        "Diferencia (puntos porcentuales)": round(change, 3),
                        "Dirección favorable": "Mayor" if higher_better else "Menor"})
            st.dataframe(pd.DataFrame(changes), hide_index=True, width="stretch")
            st.caption("Diferencia = Harp menos el estadio de referencia. Son predicciones puntuales; esta tabla no estima incertidumbre ni demuestra adaptación del jugador.")
            calibration_path = output.parent / 'reports/v9_estadios/calibracion_por_estadio.csv'
            if stadium_context and calibration_path.exists():
                calibration = pd.read_csv(calibration_path)
                hr = calibration.loc[calibration.stadium_id.eq('mexico_ahh') & calibration.task.eq('home_run_per_pitch')]
                if not hr.empty:
                    expected = (hr.predicted * hr.n).sum() / hr.n.sum()
                    observed = (hr.observed * hr.n).sum() / hr.n.sum()
                    st.warning(f"Riesgo de jonrón: en la evaluación de Harp se predijeron {100*expected:.3f} por 100 lanzamientos y se observaron {100*observed:.3f}. Una pequeña diferencia favorable del escenario no basta para recomendar mayor uso.")
            with st.expander("Ubicación, índice complementario y probabilidad de out"):
                for col, label, (_, result) in zip(st.columns(len(labels)), labels, predicted.iterrows()):
                    with col:
                        st.markdown(f"**{label}**")
                        st.metric("Location+ · ubicación", f"{result.location_plus:.1f}")
                        if has_complement:
                            st.metric("Índice integral", f"{result.indice_integral:.1f}")
                            st.metric("Out al terminar el turno", f"{100*result.p_out_within_pa:.1f}%")
                st.caption("El Índice integral es un complemento con pesos iguales; no se ha demostrado que mejore la predicción de carreras ni que optimice un arsenal para Harp.")

        if not predicted.arsenal_history_available.iloc[0]:
            st.info("Sin historial de recta primaria: el modelo recibe una bandera de arsenal ausente.")
        if has_complement:
            st.caption("Out al terminar el turno: posibilidad de registrar al menos un out en la jugada que cierra el turno al bate, desde este lanzamiento. Incluye jugadas de selección y doble play; no necesariamente sale el bateador.")
            with st.expander("Cómo leer el índice integral"):
                st.write("Reúne ocho señales: fallos de swing, swings fuera de zona, strikes cantados, contacto débil, rodados, contacto duro, carreras esperadas y out al cerrar el turno. Más de 100 indica un perfil más favorable que la referencia histórica.")
                st.write("Cada señal tiene el mismo peso después de llevarla a una escala comparable. Es un índice de comparación, no un porcentaje ni una promesa de rendimiento. Algunas señales están relacionadas entre sí.")

        for name, ref in meta["reference"].items():
            if not ref["informative"]:
                st.info(f"{name}: referencia constante; se muestra 100 y no permite ordenar lanzamientos.")

        st.caption(
            "La comparación mantiene fija la física medida. No transporta movimiento al cambiar el aire. "
            + ("El estadio procede del mapeo auditado; el delta es predictivo." if stadium_context
             else "Altitud extrema no identifica Harp Helú; el delta es predictivo.")
        )

        # Probabilities table
        probabilities = {
            "p_whiff": "Swing fallido por lanzamiento",
            "p_whiff_given_swing": "Fallo entre swings",
            "p_ball_in_play": "Bola en juego",
            "p_groundball_given_in_play": "Rodado dado bola en juego",
            "p_weak_contact": "Contacto <85 mph dado contacto medido",
            "p_hard_contact": "Contacto ≥95 mph dado contacto medido",
            "p_home_run_per_pitch": "Jonrón por pitch",
            "p_called_strike": "Strike cantado",
            "p_chase": "Swing fuera de zona por pitch",
            "p_out_within_pa": "Al menos un out al cerrar el turno al bate",
        }
        table = pd.DataFrame({"Resultado": [label for key, label in probabilities.items() if key in predicted]})
        for i, label in enumerate(labels):
            table[label] = [f"{100 * predicted.iloc[i][key]:.1f}%" for key in probabilities if key in predicted]

        with st.expander("Todas las probabilidades y sus denominadores"):
            st.dataframe(table, hide_index=True, width="stretch")
        st.caption("Estas probabilidades incorporan ubicación y contexto. Las filas condicionales tienen denominadores distintos y no deben sumarse.")

        st.download_button(
            "Descargar escenarios",
            pd.concat([scenarios.reset_index(drop=True).add_prefix("entrada_"),
                       predicted.reset_index(drop=True)], axis=1).assign(
                procedencia="Ejemplo con medianas editables; no observación verificada",
                referencia_score="Calibración fija", modelo_sha256=hashlib.sha256((output / "bundle.json").read_bytes()).hexdigest()
            ).to_csv(index=False),
            "escenarios_v9.csv",
            "text/csv",
            use_container_width=True,
        )

        # SHAP explanation
        with st.expander("Qué impulsa el Stuff+ físico", expanded=False):
            if st.button("Explicar este pitch", type="primary", key="explain_pitch"):
                from explicar_v9 import explain_physical
                explanation = explain_physical(scenarios.iloc[:1], bundle)
                if explanation["informative"]:
                    contributions = explanation["contributions"].iloc[0]
                    top = contributions.abs().sort_values(ascending=False).head(8).index
                    shown = contributions.loc[top].copy()
                    shown.loc["Otras variables"] = contributions.drop(top).sum()
                    chart_data = shown.rename("Puntos").rename_axis("Variable").reset_index()
                    chart = alt.Chart(chart_data).mark_bar().encode(
                        x="Puntos:Q",
                        y=alt.Y("Variable:N", sort="-x"),
                        color=alt.condition(
                            alt.datum.Puntos > 0,
                            alt.value("#ad1830"),
                            alt.value("#718096")
                        ),
                        tooltip=["Variable", "Puntos"],
                    ).properties(height=300)
                    st.altair_chart(chart, width="stretch")
                    st.caption(
                        f"Base del modelo: {explanation['base'][0]:.2f} puntos. "
                        f"Base + contribuciones = {explanation['score'][0]:.2f}. "
                        "Atribuciones SHAP a la predicción actual; no estiman el efecto causal de modificar una variable."
                    )
                else:
                    st.info("El modelo físico conserva un baseline constante; no hay diferencias de features que explicar.")

def render_rankings(output):
    st.subheader("Pitchers y movimiento")
    complement = Path(__file__).resolve().parent / 'reports/v9_estadios/complemento/season'
    integral_path = complement / 'pitchers_integrales.csv'
    if output.name == 'stuff_plus_output_v9_estadios' and integral_path.exists():
        with st.expander("Comparar con el promedio de cada temporada y estadio"):
            st.write("Esta tabla ajusta las puntuaciones al grupo de lanzamientos evaluados de cada temporada y estadio: 100 es su promedio y 10 puntos equivalen a una desviación estándar. Sirve para revisar esa muestra histórica; el simulador conserva una referencia fija para lanzamientos nuevos.")
            st.caption("Con menos de 300 lanzamientos o estadio desconocido se usa el promedio de la temporada. Los promedios de lanzadores combinan sus distintos estadios; no garantizan que cada lanzador tenga media 100. El ajuste usa predicciones, nunca resultados reales del año evaluado.")
            integral = pd.read_csv(integral_path)
            integral = integral.loc[integral.n_pitches.ge(100) & integral.n_games.ge(5)]
            st.dataframe(integral.sort_values('indice_integral_temporada_estadio', ascending=False).rename(columns={
                'year':'Temporada', 'pitcher_anon_id':'Lanzador', 'n_pitches':'Lanzamientos',
                'n_games':'Juegos', 'p_out_within_pa':'Probabilidad de out al cerrar el turno',
                'indice_integral':'Índice integral · referencia fija',
                'indice_integral_temporada_estadio':'Índice integral · ajustado al grupo'}), hide_index=True, width='stretch')
            st.download_button('Descargar comparación ajustada', integral_path.read_bytes(), file_name=integral_path.name, mime='text/csv')
    if (output / "pitchers.csv").exists():
        pitchers = pd.read_csv(output / "pitchers.csv")

        filter_col, _ = st.columns([1, 3])
        with filter_col:
            min_pitches = st.checkbox("Al menos 100 pitches y cinco juegos", value=True, key="filter_pitchers")

        if min_pitches:
            pitchers = pitchers.loc[pitchers.n_pitches.ge(100) & pitchers.n_games.ge(5)]

        movement = pd.read_csv(output / "mapa_movimiento.csv")
        candidates = sorted(set(movement.pitcher_anon_id.dropna()) & set(pitchers.pitcher_anon_id.dropna()))
        if not candidates:
            st.info("No hay pitchers con soporte suficiente para este filtro. Desactívalo para ampliar la muestra.")
            return
        if st.session_state.get("movement_pitcher") not in candidates:
            st.session_state["movement_pitcher"] = candidates[0]
        chosen = st.selectbox("Pitcher que quieres revisar", candidates, key="movement_pitcher")
        st.caption("La ficha, el mapa y el arsenal siguientes pertenecen a este mismo pitcher. Son resultados históricos de evaluación, no una proyección de talento.")
        st.dataframe(
            pitchers.loc[pitchers.pitcher_anon_id.eq(chosen)].rename(columns={
                "pitcher_anon_id": "Lanzador anónimo", "year": "Temporada", "n_pitches": "Lanzamientos",
                "n_games": "Juegos", "stuff_plus": "Stuff+ · física", "location_plus": "Location+ · ubicación",
                "pitching_plus": "Pitching+ · combinado"}),
            hide_index=True,
            width="stretch",
        )
        st.caption(
            "Promedios descriptivos de los pitches evaluados. "
            "La muestra y el contexto afectan el ranking; no son estimaciones de talento ni intervalos de confianza."
        )

        with st.expander("Ver el ranking completo de pitchers"):
            st.dataframe(pitchers.sort_values("pitching_plus", ascending=False).rename(columns={
                "pitcher_anon_id": "Lanzador", "n_pitches": "Lanzamientos", "n_games": "Juegos",
                "stuff_plus": "Stuff+", "location_plus": "Location+", "pitching_plus": "Pitching+"
            }), hide_index=True, width="stretch")

        # Movement map
        st.markdown("### Mapa de movimiento")
        local = movement.loc[movement.pitcher_anon_id.eq(chosen)]

        color_options = {
            "stuff_plus": "Stuff+",
            "pitching_plus": "Pitching+",
        }
        color_key = st.selectbox(
            "Color del mapa",
            list(color_options.keys()),
            format_func=lambda x: color_options[x],
            key="movement_color"
        )

        chart = alt.Chart(local).mark_circle(opacity=0.85).encode(
            x=alt.X("HB:Q", title="HB normalizado por mano (pulgadas)"),
            y=alt.Y("IVB:Q", title="IVB (pulgadas)"),
            size=alt.Size("n:Q", title="Pitches", scale=alt.Scale(range=[20, 500])),
            color=alt.Color(f"{color_key}:Q", title=color_options[color_key], scale=alt.Scale(scheme="redyellowgreen")),
            shape="AutoPitchType:N",
            tooltip=["AutoPitchType", "altitude_category", "n", "velocity", "stuff_plus", "pitching_plus"],
        ).interactive().properties(height=450)

        st.altair_chart(chart, width="stretch")
        st.caption(
            "Cada punto es una media por tipo y categoría de altitud; no muestra trayectorias ni pitches individuales. "
            "HB de zurdos se refleja para comparar por mano."
        )

        # Arsenal
        st.markdown("### Arsenal del pitcher")
        arsenal_path = output / "arsenal.csv"
        if arsenal_path.exists():
            arsenal = pd.read_csv(arsenal_path)
            st.dataframe(
                arsenal.loc[arsenal.pitcher_anon_id.eq(chosen)].rename(columns={
                    "pitcher_anon_id": "Lanzador anónimo", "AutoPitchType": "Tipo de lanzamiento",
                    "altitude_category": "Categoría de altitud", "year": "Temporada", "n_pitches": "Lanzamientos",
                    "n_games": "Juegos", "stuff_plus": "Stuff+", "location_plus": "Location+", "pitching_plus": "Pitching+"}),
                hide_index=True,
                width="stretch",
            )
    else:
        st.info("La evaluación genera los agregados de pitchers y el mapa.")

def render_evidence(output, bundle):
    meta = bundle[0]
    with st.expander("Qué está demostrado y qué falta para la entrega", expanded=True):
        st.write("Disponibles: scores y agregados, comparación predictiva, mapa, documento técnico y pruebas por temporada, pitcher y Harp reservado.")
        st.write("Pendiente: demostrar una ventaja específica de forma y arsenal en Harp, validar la utilidad deportiva del índice integral y medir cambios reales de movimiento entre entornos.")
        st.caption("Los perfiles físicos son referencias descriptivas. Las mejoras de interfaz no cambian la evidencia de los modelos ni convierten el contraste en un efecto causal.")
        metrics_path = output / "metricas.json"
        if metrics_path.exists():
            rows = json.loads(metrics_path.read_text())
            baseline_rows = []
            for item in rows:
                if item['task'] in {'stuff_run_value', 'environment_run_value'}:
                    metrics = item['metrics']
                    baseline_rows.append({'Modelo': TASK_NAMES[item['task']],
                        'RMSE': metrics['rmse'], 'RMSE del promedio por conteo': metrics['count_baseline_rmse'],
                        'Reducción MSE frente a conteo (%)': round(100*metrics['mse_skill_vs_count'], 2)})
            st.dataframe(pd.DataFrame(baseline_rows), hide_index=True, width='stretch')
            st.caption('Un porcentaje negativo indica mayor error. El modelo físico recibe menos contexto que el promedio por conteo; la ganancia del combinado no debe atribuirse al estadio.')
        revision = output.parent / 'reports/v9_estadios/MEJORAS_2026-10-28.md'
        if revision.exists():
            st.download_button('Cambios y pendientes de esta revisión', revision.read_bytes(), revision.name)
    st.subheader("Cómo se validó")
    supplement = Path(__file__).resolve().parent / 'reports/v9_estadios/complemento'
    if output.name == 'stuff_plus_output_v9_estadios' and (supplement / 'park/metricas.json').exists():
        with st.expander("Pruebas de la probabilidad de out al terminar el turno"):
            records = []
            for mode, label in [('season', 'Temporada 2026'), ('pitcher', 'Lanzadores reservados'), ('park', 'Harp fuera del entrenamiento')]:
                item = json.loads((supplement / mode / 'metricas.json').read_text())
                records.append({'Prueba':label, 'Lanzamientos evaluados':item['pitches'], 'Turnos':item['pa'],
                    'Error de probabilidad (menor es mejor)':round(item['brier'], 4),
                    'Reducción frente al promedio por conteo':f"{item['gain']['gain']:.2%}"})
            st.dataframe(pd.DataFrame(records), hide_index=True, width='stretch')
            st.caption("Solo se evalúan turnos reconstruidos completos. Un mismo turno aporta varios lanzamientos; los intervalos remuestrean juegos completos. No es una prueba futura intacta.")
    render_validation_summary(output)
    st.write(
        "Los juegos se separan en ajuste, parada temprana, calibración, búsqueda y confirmación. "
        "La temporada de evaluación no decide modelos ni escalas."
    )

    with st.expander("Detalle para el equipo de análisis", expanded=False):
        st.markdown("### Selección de modelos")
        st.dataframe(
            pd.DataFrame([{
                "Resultado": TASK_NAMES.get(task, task),
                "Predicción elegida": {"raw": "Modelo", "sigmoid": "Modelo calibrado", "shrink": "Modelo ajustado", "parent": "Capa anterior", "baseline": "Promedio de referencia"}.get(item["selection"].get("selected", "baseline"), "Promedio de referencia"),
                "Comparada contra": TASK_NAMES.get(item["selection"].get("control_task"), "Promedio de referencia"),
                "Confirmada": item["selection"]["promoted"],
                "Filas de ajuste": item["n_fit"],
            } for task, item in meta["tasks"].items()]),
            hide_index=True,
            width="stretch",
        )

        if (output / "ablaciones.json").exists():
            st.markdown("### Ablaciones: cambio de error al añadir ubicación, arsenal y entorno")
            st.dataframe(
                pd.DataFrame(json.loads((output / "ablaciones.json").read_text())),
                hide_index=True,
                width="stretch",
            )
            st.caption(
                "Ganancia = 1 − MSE nuevo / MSE anterior. Intervalos mediante remuestreo de juegos. "
                "No representan efectos causales."
            )

if __name__ == "__main__":
    st.set_page_config(page_title="Diablos · Simulador v9", layout="wide")
    apply_dashboard_style()
    render(Path(__file__).resolve().parent / "stuff_plus_output_v9")
